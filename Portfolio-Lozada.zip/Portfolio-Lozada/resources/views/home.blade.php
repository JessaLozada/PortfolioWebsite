<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" contente="ie=edge">
	<title>Portfolio Website</title>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
	
	<style type="text/css">	
*{
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}
body{
	font-family: Arial, Helvetica, sans-serif;
	line-height: 1.6;
	height: 100vh;
	/*overflow: hidden;*/
}
.container{
	width: 100%; 
	height: 100%;
	/* CSS Smooth Scroll */
	overflow-y: Scroll;
	scroll-behavior: smooth;
	scroll-snap-type: y mandatory;
}
header{
	position: fixed;
	top: 0;
	z-index: 1;
	display: flex;
	width: 100%;
	background: rgba(0,0,0,7);
}
header ul{
	display: flex;
	list-style: none;
	width: 100%;
	justify-content: center;
}
header ul li{
	margin: 0 1rem;
	padding: 1rem;
}
header ul li a{
	text-decoration: none;
	text-transform: uppercase;
	color: #f4f4f4;
}
header ul li a:hover, .btn:hover{
	color: #FF0099;
}
.btn{
	width: 100px;
	height: 35px;
	background: none;
	color: #f4f4f4;
	border: 2px solid #f4f4f4;
	border-radius: 30px;
	margin-top: 10px;
}

section#home{
	background: url("Pictures/first.jpg") no-repeat center center/cover;
	height: 100vh;
}
#home{
	display: flex;
	flex-direction: column;
	width: 100%;
	height: 100vh;
}
#home h1{
	font-size: 5rem;
	margin-top: 80px;
	margin-left: 150px;
	font-family: Courier, monospace;
	background: linear-gradient(black, hotpink);
	background-size: cover;
 	-webkit-text-fill-color: transparent;
 	-webkit-background-clip: text;
 	-moz-background-clip: text;
 	background-clip: text;
 	-webkit-text-stroke: 2px #ffe6e6;
	letter-spacing: 2px;
}
#home .profile{
	position: relative;
	width: 100px;
	height: 100px;
	margin-bottom: 20px;
	left: 50%;
	border-radius: 50%;
	transform: translateX(-50%);
	background-color: rgba(0,0,0,0.6);
}
#home .profile img{
	width: 100px;
	height: 100px;
	padding: 5px;
}
#home h2{
	position: relative;
	left: 50%;
	transform: translate(-50%, -50%);
	font-family: 'Trocchi', serif;
	text-align: center;
	color: #FFFFCC;
	-webkit-text-stroke: 1px orange;
	font-weight: bold;
	font-size: 40px;
}
#home p{
	position: relative;
	left: 50%;
	width: 25%;
	transform: translate(-50%, -50%);
	padding: 5px 5px;
	text-align: center;
	font-family: merienda;
	font-size: 18px;
	color: #fff;
	border: 2px inset #fff;
	background-color: rgba(0,0,0,0.5);
}
#home p:hover{
	color: #000;
}
#home p::before{
	content: '';
	background-color: #D2D2D2;
	position: absolute;
	left: 0;
	top: 0;
	width: 100%;
	height: 0%;
	z-index: -1;
	transition: .5s;
}
#home p:hover::before{
	height: 100%;
}

section#about{
	background: url("Pictures/second.jpg") no-repeat center center/cover;
	height: 100%;
}
#about .wrapper h3{
	letter-spacing: 3px;
	font-size: 35px;
	-webkit-text-stroke: 1px orange;
}
#about .wrapper{
	position: relative;
	top: 45%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 55%;
	padding: 30px 30px;
	font-family: merienda;
	border-top-right-radius: 50px;
	border-bottom-left-radius: 50px;
	background-color: rgba(0,0,0,0.6);
	color: #fff;
}
#about .wrapper p{
	font-size: 18px;
}

section#contact{
	background: url("Pictures/third.jpg") no-repeat center center/cover;
	min-height: 100vh;
	width: 100%;
	font-family: "Poppins", sans-serif;
	background-size: cover;
	display: flex;
	justify-content: center;
	align-items: center;
}
.contact-info{
	color: #fff;
	max-width: 400px;
	line-height: 65px;
	padding-left: 50px;
	font-size: 18px;
}
.contact-info i{
	margin-right: 10px;
	font-size: 25px;
}
.contact-form{
	max-width: 500px;
	margin-right: 50px;
}
.contact-info, .contact-form{
	flex: 1;
}
.contact-form h2{
	color: #fff;
	text-align: center;
	font-size: 35px;
	text-transform: uppercase;
	margin-bottom: 30px;
}
.contact-form .text-box{
	background: #000;
	color: #fff;
	border: none;
	width: calc(50% - 10px);
	height: 50px;
	padding: 12px;
	font-size: 15px;
	border-radius: 5px;
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
	margin-bottom: 20px;
	opacity: 0.9;
}
.contact-form .text-box:first-child{
	margin-right: 15px;
}
.contact-form textarea{
	background: #000;
	color: #fff;
	border: none;
	width: 100%;
	padding: 12px;
	font-size: 15px;
	min-height: 200px;
	max-height: 400px;
	resize: vertical;
	border-radius: 5px;
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
	margin-bottom: 20px;
	opacity: 0.9;
}
.contact-form .send-btn{
	float: right;
	background: #2E94E3;
	color: #fff;
	border: none;
	width: 120px;
	height: 40px;
	font-size: 15px;
	font-weight: 600;
	text-transform: uppercase;
	letter-spacing: 2px;
	border-radius: 5px;
	cursor: pointer;
	transition: 0.3s;
	transition-property: background;
}
.contact-form .send-btn:hover{
	background: #0582E3;
}

footer{
	background: black;
}
footer p{
	font-family: merienda;
	text-align: center;
	color: pink;
	padding: 5px;
	font-weight: bold;
}
	</style>

</head>
<body>
	<div class="container">
		<header>
			<ul>
				<li><a href="#home">Homepage</a></li>
				<li><a href="#about">About me Page</a></li>
				<li><a href="#contact">Contact Page</a></li>
				<button class="btn">Get Started</button>
			</ul>
		</header>
		<section id="home">
			<h1>HELLO!</h1>
			<div class="profile">
				<img src="Pictures/blink.png">
			</div>
			<h2>Jessayet</h2>
			<p>Ang malanding <span style="color: red">Designer.</span></p>
		</section>
		<section id="about">
			<div class="wrapper">
				<h3>Hello everyone,</h3>
				<p>My name is Jessa Mae Lozada, my friends call me Jessayet.
				I'm 20 years old and I was born on June 28, 2000 here in San Manuel Pangasinan. I am currently taking up BS in Information Technology at Urdaneta City University.</p>
				<p>I'm the type of girl who didn't want to be a <span style="color: red">Princess,</span>, Im priceless. A <span style="color: red">Prince</span> not even on my list.
				Love is a drug that I quit. No doctor could help when I’m lovesick.</p>
			</div>
		</section>
		<section id="contact">
			<div class="contact-info">
				<div><i class="fas fa-map-marker"></i>San Manuel,Pangasinan</div>
				<div><i class="fas fa-envelope"></i>Jessayet@gmail.com</div>
				<div><i class="fas fa-phone"></i>+63 9123 456 789</div>
				<div><i class="fas fa-clock"></i>Mon - Fri 8:00 AM to 5:00 PM</div>
			</div>
			<div class="contact-form">
				<h2>Contact Us</h2>
				<form class="contact" method="post">
					<input type="text" name="name" class="text-box" placeholder="Your Name" required>
					<input type="email" name="email" class="text-box" placeholder="Your Email" required>
					<textarea name="message" rows="5" placeholder="Your Message" required></textarea>
					<input type="submit" name="submit" class="send-btn" value="send">
				</form>
			</div>
		</section>
		<footer>
			<hr>
			<p>No Copyright, Kiss me first!</p>
		</footer>
	</div>
</body>
</html>